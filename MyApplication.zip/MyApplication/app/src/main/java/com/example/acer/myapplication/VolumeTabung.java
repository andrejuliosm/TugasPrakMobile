package com.example.acer.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class VolumeTabung extends AppCompatActivity {
    private Button btnHasil;
    private TextView tvHasil;
    private EditText etTinggi,etRadius;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volume_tabung);
        btnHasil = findViewById(R.id.btn_hasil);
        tvHasil = findViewById(R.id.tv_hasil);
        etTinggi = findViewById(R.id.et_tinggi);
        etRadius = findViewById(R.id.et_radius);



        btnHasil.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v){
                                            try{
                                                String sTinggi = etTinggi.getText().toString();
                                                String sRadius = etRadius.getText().toString();


                                                double tinggi = Double.parseDouble(sTinggi);
                                                double radius = Double.parseDouble(sRadius);

                                                double hasil = 3.14*radius*radius*tinggi;

                                                String sHasil = String.valueOf(hasil);
                                                tvHasil.setText(sHasil);
                                            }catch (NumberFormatException nfe){
                                                Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong Ya",Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    }
        );
    }

}
