package com.example.acer.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class VolumeKubus extends AppCompatActivity {
    private Button btnHasil;
    private TextView tvHasil;
    private EditText etSisi;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volume_kubus);btnHasil = findViewById(R.id.btn_hasil);
        tvHasil = findViewById(R.id.tv_hasil);
        etSisi = findViewById(R.id.et_sisi);




        btnHasil.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v){
                                            try{
                                                String sSisi = etSisi.getText().toString();


                                                double sisi = Double.parseDouble(sSisi);


                                                double hasil = sisi*sisi*sisi;

                                                String sHasil = String.valueOf(hasil);
                                                tvHasil.setText(sHasil);
                                            }catch (NumberFormatException nfe){
                                                Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong Ya",Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    }
        );
    }

}
